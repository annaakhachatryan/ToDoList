import React, {useState, useMemo,useCallback} from 'react'
import { Post } from '../../Components/Post/Post';

export const Posts = () => {
    const [text, setText] = useState('')
    const [number, setNumber] = useState(1)

    const post = useMemo(()=>{
        return {
            name:'an'
        }
    }, [])

    const numInc = useCallback(()=>{
        setNumber(number + 1)
    }, [number])

    return (
        <div className='Posts'>
            <div>
            <input value={text} 
                type='text'
                placeholder='Write!'
                onChange={(e)=>setText(e.target.value)} />
            <h1>Input Text : {text}</h1>
            <h1>CountNumber : {number}</h1>
            </div>

            <Post post={post} numInc={numInc} />
        </div>
    )
}
