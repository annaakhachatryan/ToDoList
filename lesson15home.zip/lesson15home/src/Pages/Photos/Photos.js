import React, { useState, useMemo } from 'react'
import { Photo } from '../../Components/Photo/Photo'

export const Photos = () => {
    const [text, setText] = useState('')

    const photoMemo = useMemo(() => {
        return {
            name: 'as',
            lastName: 'last'
        }
    }, [])

    return (
        <div className='Photos'>
            <input type='text'
                placeholder='Write!'
                value={text}
                onChange={(e) => setText(e.target.value)}
            />
            <h1>Input Text : {text}</h1>

            <hr/>
            <Photo photoMemo={photoMemo} />
        </div>
    )
}
