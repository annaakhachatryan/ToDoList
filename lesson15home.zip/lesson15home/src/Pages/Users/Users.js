import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

export const Users = () => {
    const [users, setUsers] = useState([])

    useEffect(()=>{
        fetch('https://jsonplaceholder.typicode.com/users')
        .then(res=>res.json())
        .then(data => setUsers(data))
    },[])
    return (
        <div className='Users'>
            {
                users.map(user =>
                    <div className='link' key={user.id}>
                        <Link  to={`${user.id}`}>{user.name}</Link>
                    </div>
                )
            }
        </div>
    )
}
