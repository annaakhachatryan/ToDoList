import React from 'react'
import { NavLink, Outlet } from 'react-router-dom'

export const Layout = () => {
    return (
        <div>
            <header className='headerLink'>
                <NavLink to='/'>User</NavLink>
                <NavLink to='/posts'>Post</NavLink>
                <NavLink to='/photos'>Photos</NavLink>
            </header>
            <Outlet/>
        </div>
    )
}
