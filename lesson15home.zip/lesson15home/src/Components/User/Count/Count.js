import React from 'react'
import { useRef, useEffect, useState, memo } from 'react'
import { useParams, useNavigate } from 'react-router'

export const Count = memo(({obj, number }) => {
    const ref = useRef(null)
    ref.current++
    const [user, setUser] = useState({})
    const navigate = useNavigate()
    const {id} = useParams()

    useEffect(() => {
        fetch(`https://jsonplaceholder.typicode.com/users/${id}`)
        .then(res => res.json())
        .then(data=>setUser(data))
    }, [id])
    const back = () =>{
        navigate(-1)
    }
    
    // console.log(user);

    return (
        <div>
            <button onClick={back}>Back</button>
            <div className='bigDiv'>
                <div>
                    <h2>ID : {user.id}</h2>
                    <p>Name : {user.name}</p>
                    <p>UserName : {user.username}</p>
                    <p>Email: {user.email}</p>
                    <p>Phone : {user.phone}</p>
                    <p>Website : {user.website}</p>
                </div>
            </div>
            <h2>{ref.current}</h2>
            <button onClick={number}>+</button>
            <h1>{obj.name}</h1>
        </div>
    )
})
