import React, { useCallback, useState, useMemo } from 'react'
import { Count } from './Count/Count'

export const User = () => {
    const [countNumber, setCountNumber] = useState(1)
    const [text, setText] = useState('')

    const users = useMemo(()=>{
        return{
            name:'Anna Khachatryan'
        }
    }, [])

    const number = useCallback(()=>{
        setCountNumber(countNumber + 1)
    }, [countNumber])

    return (
        <div className='User'>
            <h1>CountNumber : {countNumber}</h1>
            <h1>Input Text : {text}</h1>
            <input type='text'
            placeholder='Write!'
            value={text}
            onChange={(e)=>setText(e.target.value)}
            />
            
            <Count obj = {users} number={number}/>
        </div>
    )
}
