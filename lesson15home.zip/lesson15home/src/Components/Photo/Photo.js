import React, { useRef, useEffect, useState, memo } from 'react'

export const Photo = memo(({ photoMemo }) => {
    const ref = useRef(null)
    ref.current++
    const [photos, setPhotos] = useState([])
    const [eachPhotosIndex, setEachPhotosIndex] = useState(0)
    const [addImg, setAddImg] = useState(null)
    const [addPhoto, setAddPhoto] = useState({
        title: '',
        userName: '',
        description: '',
        url: '',
    })
    const handlerSubmitFor = (e) => {
        e.preventDefault()
        let obj = {
            id: new Date().getTime().toString(),
            url: addImg,
            title: addPhoto.title,
            userName: addPhoto.userName,
            description: addPhoto.description,
        }
        setPhotos([...photos, obj])
        

        setAddPhoto({
            title: '',
            description: '',
            userName: '',
        })
    }
    const addUsers = (e) => {
        const { name, value } = e.target
        setAddPhoto({ ...addPhoto, [name]: value })
    }
console.log(photos);


    const changeFile = (e) => {
        const reader = new FileReader()
        reader.readAsDataURL(e.target.files[0])
        reader.onload = () => {
            setAddImg(reader.result)
        }
    }

    useEffect(() => {
        const getPhotos = async () => {
            const res = await fetch('https://jsonplaceholder.typicode.com/photos?_limit=5')
            const jsonRes = await res.json()

            const data = [
                ...jsonRes.map((photo) => ({
                    id: photo.id,
                    title: photo.title,
                    url: photo.url,
                    description: 'Lovely photo',
                    userName: 'User Name',
                }))
            ]
            setPhotos(data)
        }
        getPhotos()
    }, [])

    // console.log(photos);

    return (
        <div>
            <form onSubmit={handlerSubmitFor}>
                <input onChange={addUsers} type='text' name='title' placeholder='Title' value={addPhoto?.name} />
                <input onChange={addUsers} type='text' name='userName' placeholder='User name' value={addPhoto?.lastName} />
                <input onChange={addUsers} type='text' name='description' placeholder='Description' value={addPhoto?.description} />
                <input onChange={changeFile} type='file' name='url' />
                <button>Add</button>
            </form>
            <button onClick={eachPhotosIndex === photos.length - 1 ? null : () => setEachPhotosIndex(eachPhotosIndex + 1)}>+</button>
            <div className='bigDiv'>
                <div>
                    <h2><span>ID : </span> {photos[eachPhotosIndex]?.id} </h2>
                    <p><span>Title : </span> {photos[eachPhotosIndex]?.title} </p>
                    <p><span>Description : </span> {photos[eachPhotosIndex]?.description} </p>
                    <p><span>Username : </span> {photos[eachPhotosIndex]?.userName} </p>
                    <img style={{ width: '80px' }} src={photos[eachPhotosIndex]?.url} alt='' />
                </div>
            </div>
            <button onClick={eachPhotosIndex === 0 ? null : () => setEachPhotosIndex(eachPhotosIndex - 1)}>-</button>
            <h2>{ref.current}</h2>

            <div style={{border:'2px solid', padding:'10px'}}>
                <h1>{photoMemo.name}</h1>
                <h1>{photoMemo.lastName}</h1>
            </div>
        </div>
    )
})
