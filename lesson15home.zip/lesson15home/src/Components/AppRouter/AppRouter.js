import React from 'react'
import { Route, Routes } from 'react-router'
import { Layout } from '../../Pages/Layout/Layout'
import { Posts } from '../../Pages/Posts/Posts'
import {Users} from '../../Pages/Users/Users'
import {User} from '../../Components/User/User'
import { Photos } from '../../Pages/Photos/Photos'

export const AppRouter = () => {
    return (
        <div>
            <Routes>
                <Route path='/' element={<Layout/>}>
                    <Route path='/' element={<Users/>}/>
                    <Route path='/:id' element={<User />} />
                    <Route path='posts' element={<Posts/>}/>
                    <Route path='photos' element={<Photos/>}/>
                </Route>
            </Routes>
        </div>
    )
}
