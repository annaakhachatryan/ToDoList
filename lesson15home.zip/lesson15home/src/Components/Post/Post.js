import React from 'react'
import { memo, useEffect, useRef } from 'react'
import { useState } from 'react'
export const Post = memo(({ post, numInc }) => {
    const refCount = useRef(null)
    refCount.current++
    const [posts, setPosts] = useState([])
    const [eachPostIndex, setEachPostIndex] = useState(0)

    useEffect(() => {
        const getPost = async () => {
            const res = await fetch('https://jsonplaceholder.typicode.com/posts?_limit=5')
            const jsonRes = await res.json()

            const data = [
                ...jsonRes.map(post => ({
                    id: post.id,
                    title: post.title,
                    body: post.body,
                    userName: 'User Name',
                    description: 'Always happy!'
                }))
            ]
            setPosts(data)
        }
        getPost()
    }, [])
    console.log(posts);
    return (
        <div>

            <button onClick={eachPostIndex === posts.length - 1 ? null : () => setEachPostIndex(eachPostIndex + 1)}>+</button>
            <div className='bigDiv'>
                <div>
                    <h2><span>ID : </span>{posts[eachPostIndex]?.id}</h2>
                    <p><span>Title : </span>{posts[eachPostIndex]?.title}</p>
                    <p><span>Body : </span>{posts[eachPostIndex]?.body}</p>
                    <p><span>Username : </span>{posts[eachPostIndex]?.userName}</p>
                    <p><span>Description : </span>{posts[eachPostIndex]?.description}</p>
                </div>
            </div>
            <button onClick={eachPostIndex === 0 ? null : () => setEachPostIndex(eachPostIndex - 1)}>-</button>

            <h1>{refCount.current}</h1>
            <button onClick={numInc}>+</button>
        </div>
    )
})
